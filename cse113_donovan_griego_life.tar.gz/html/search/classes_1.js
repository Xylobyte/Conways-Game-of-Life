var searchData=
[
  ['sdl_5finfo_5ft_38',['sdl_info_t',['../structsdl__info__t.html',1,'']]]
];
