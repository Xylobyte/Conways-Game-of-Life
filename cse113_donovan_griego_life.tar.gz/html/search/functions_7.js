var searchData=
[
  ['sdl_5frender_5flife_57',['sdl_render_life',['../sdl_8h.html#afec672c5d4f9b0381339bd3229f28889',1,'sdl.h']]],
  ['sdl_5ftest_58',['sdl_test',['../sdl_8h.html#ada6b3150b36edb0a418e47d340006ea4',1,'sdl.h']]],
  ['set_5flife_59',['set_life',['../life_8c.html#ade035821b67cf7be1e00e366755d62eb',1,'set_life(unsigned char **life, int row, int col, unsigned char x, char type):&#160;life.c'],['../life_8h.html#ade035821b67cf7be1e00e366755d62eb',1,'set_life(unsigned char **life, int row, int col, unsigned char x, char type):&#160;life.c']]]
];
