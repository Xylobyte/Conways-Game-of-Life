var searchData=
[
  ['color_5ft_37',['color_t',['../structcolor__t.html',1,'']]]
];
