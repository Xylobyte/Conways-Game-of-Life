var searchData=
[
  ['kill_5fedges_14',['kill_edges',['../life_8c.html#a830d284777fa777ce4269227f242994b',1,'kill_edges(unsigned char **mat, int rows, int cols):&#160;life.c'],['../life_8h.html#a830d284777fa777ce4269227f242994b',1,'kill_edges(unsigned char **mat, int rows, int cols):&#160;life.c']]]
];
