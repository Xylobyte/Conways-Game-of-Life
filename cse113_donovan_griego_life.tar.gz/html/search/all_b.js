var searchData=
[
  ['screen_25',['screen',['../structsdl__info__t.html#ace88dc90952d64264b8f8ceedc5f1847',1,'sdl_info_t']]],
  ['sdl_2eh_26',['sdl.h',['../sdl_8h.html',1,'']]],
  ['sdl_5finfo_5ft_27',['sdl_info_t',['../structsdl__info__t.html',1,'']]],
  ['sdl_5frender_5flife_28',['sdl_render_life',['../sdl_8h.html#afec672c5d4f9b0381339bd3229f28889',1,'sdl.h']]],
  ['sdl_5ftest_29',['sdl_test',['../sdl_8h.html#ada6b3150b36edb0a418e47d340006ea4',1,'sdl.h']]],
  ['set_5flife_30',['set_life',['../life_8c.html#ade035821b67cf7be1e00e366755d62eb',1,'set_life(unsigned char **life, int row, int col, unsigned char x, char type):&#160;life.c'],['../life_8h.html#ade035821b67cf7be1e00e366755d62eb',1,'set_life(unsigned char **life, int row, int col, unsigned char x, char type):&#160;life.c']]],
  ['sprite_5fsize_31',['sprite_size',['../structsdl__info__t.html#ab25151bb7aded0b292222bcddb8314e1',1,'sdl_info_t']]]
];
