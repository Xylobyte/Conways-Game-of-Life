var searchData=
[
  ['life_2ec_15',['life.c',['../life_8c.html',1,'']]],
  ['life_2eh_16',['life.h',['../life_8h.html',1,'']]],
  ['life_5fto_5fcalc_17',['life_to_calc',['../life_8c.html#a2477d2d94fa568f7edb6c364fecc704d',1,'life_to_calc(unsigned char **life, unsigned char **calc, int rows, int cols, char type):&#160;life.c'],['../life_8h.html#a2477d2d94fa568f7edb6c364fecc704d',1,'life_to_calc(unsigned char **life, unsigned char **calc, int rows, int cols, char type):&#160;life.c']]],
  ['load_5ffile_18',['load_file',['../life_8c.html#a29c7caf2db8b1b66606bddd97ed38890',1,'load_file(unsigned char **calc, FILE *fp, int x, int y, char type):&#160;life.c'],['../life_8h.html#a29c7caf2db8b1b66606bddd97ed38890',1,'load_file(unsigned char **calc, FILE *fp, int x, int y, char type):&#160;life.c']]]
];
