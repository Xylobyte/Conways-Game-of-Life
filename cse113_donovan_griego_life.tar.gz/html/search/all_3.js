var searchData=
[
  ['gl_2ec_8',['gl.c',['../gl_8c.html',1,'']]],
  ['green_9',['green',['../structcolor__t.html#a85e1636e41c5772cf432e4612ed00310',1,'color_t']]]
];
