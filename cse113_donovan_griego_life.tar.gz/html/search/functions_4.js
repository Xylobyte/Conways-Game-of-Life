var searchData=
[
  ['life_5fto_5fcalc_51',['life_to_calc',['../life_8c.html#a2477d2d94fa568f7edb6c364fecc704d',1,'life_to_calc(unsigned char **life, unsigned char **calc, int rows, int cols, char type):&#160;life.c'],['../life_8h.html#a2477d2d94fa568f7edb6c364fecc704d',1,'life_to_calc(unsigned char **life, unsigned char **calc, int rows, int cols, char type):&#160;life.c']]],
  ['load_5ffile_52',['load_file',['../life_8c.html#a29c7caf2db8b1b66606bddd97ed38890',1,'load_file(unsigned char **calc, FILE *fp, int x, int y, char type):&#160;life.c'],['../life_8h.html#a29c7caf2db8b1b66606bddd97ed38890',1,'load_file(unsigned char **calc, FILE *fp, int x, int y, char type):&#160;life.c']]]
];
