var searchData=
[
  ['init_5falive_47',['init_alive',['../life_8c.html#abc3710eb3bf768d80f01f85d66ff5306',1,'init_alive(unsigned char **mat, int rows, int cols, char type):&#160;life.c'],['../life_8h.html#abc3710eb3bf768d80f01f85d66ff5306',1,'init_alive(unsigned char **mat, int rows, int cols, char type):&#160;life.c']]],
  ['init_5fdead_48',['init_dead',['../life_8c.html#a6a28fa60153809b492b13e9aa82cab55',1,'init_dead(unsigned char **mat, int rows, int cols, char type):&#160;life.c'],['../life_8h.html#a6a28fa60153809b492b13e9aa82cab55',1,'init_dead(unsigned char **mat, int rows, int cols, char type):&#160;life.c']]],
  ['init_5fsdl_5finfo_49',['init_sdl_info',['../sdl_8h.html#a1094292af49bb6c4abf089ab73a79bb9',1,'sdl.h']]]
];
