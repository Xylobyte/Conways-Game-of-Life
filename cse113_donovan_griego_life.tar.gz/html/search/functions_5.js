var searchData=
[
  ['main_53',['main',['../gl_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'gl.c']]],
  ['modulo_54',['modulo',['../life_8c.html#a852fa11dd63dc2c01515fe2064619240',1,'modulo(int x, int N):&#160;life.c'],['../life_8h.html#a852fa11dd63dc2c01515fe2064619240',1,'modulo(int x, int N):&#160;life.c']]]
];
