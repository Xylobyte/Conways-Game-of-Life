var searchData=
[
  ['free_5fmatrix_7',['free_matrix',['../life_8c.html#ac10a15b6fd65be361cb2da73629a73c7',1,'free_matrix(unsigned char **mat, int rows, int cols):&#160;life.c'],['../life_8h.html#ac10a15b6fd65be361cb2da73629a73c7',1,'free_matrix(unsigned char **mat, int rows, int cols):&#160;life.c']]]
];
