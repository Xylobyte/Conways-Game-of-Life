var searchData=
[
  ['calc_5fto_5flife_2',['calc_to_life',['../life_8c.html#a0caacfd58f28d6ff9020647ac07a7be1',1,'calc_to_life(unsigned char **calc, unsigned char **life, int rows, int cols, char type):&#160;life.c'],['../life_8h.html#a0caacfd58f28d6ff9020647ac07a7be1',1,'calc_to_life(unsigned char **calc, unsigned char **life, int rows, int cols, char type):&#160;life.c']]],
  ['color_3',['color',['../structsdl__info__t.html#a793e548fc0386a76cdee71647bd096d4',1,'sdl_info_t']]],
  ['color_5ft_4',['color_t',['../structcolor__t.html',1,'']]],
  ['count_5fneighbors_5',['count_neighbors',['../life_8c.html#a37308de60527d8b1d07f4a4c75391868',1,'count_neighbors(unsigned char **calc, int rows, int cols, int row, int col, char type):&#160;life.c'],['../life_8h.html#a37308de60527d8b1d07f4a4c75391868',1,'count_neighbors(unsigned char **calc, int rows, int cols, int row, int col, char type):&#160;life.c']]],
  ['create_5fmatrix_6',['create_matrix',['../life_8c.html#afa80deba73d348581b3e7cdf27c8608b',1,'create_matrix(int rows, int cols):&#160;life.c'],['../life_8h.html#afa80deba73d348581b3e7cdf27c8608b',1,'create_matrix(int rows, int cols):&#160;life.c']]]
];
