var searchData=
[
  ['print_5fmatrix_55',['print_matrix',['../life_8c.html#a0f0e8640fb01abaffc52ddae1a422dd6',1,'print_matrix(unsigned char **mat, int rows, int cols):&#160;life.c'],['../life_8h.html#a0f0e8640fb01abaffc52ddae1a422dd6',1,'print_matrix(unsigned char **mat, int rows, int cols):&#160;life.c']]],
  ['process_5fgen_56',['process_gen',['../life_8c.html#a90911dd2093a8908ec4dbc673feedc26',1,'process_gen(unsigned char **calc, unsigned char **life, int rows, int cols, char type):&#160;life.c'],['../life_8h.html#a90911dd2093a8908ec4dbc673feedc26',1,'process_gen(unsigned char **calc, unsigned char **life, int rows, int cols, char type):&#160;life.c']]]
];
